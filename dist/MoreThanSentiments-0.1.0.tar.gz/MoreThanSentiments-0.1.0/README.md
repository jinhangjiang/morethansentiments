# MoreThanSentiments
Besides sentiment scores, this Python package offers various ways of quantifying text corpus based on multiple works of literature, such as Boilerplate (Lang and Stice-Lawrence, 2015).

## Installation

The easiest way to install the toolbox is via pip (pip3 in some
distributions):

    pip install morethansentiments
    

## Usage

Please refer to the 'Boilerplate.ipynb'
